//
//  ViewController.h
//  FDApplePaySample
//
//  Created by Raghu Vamsi on 6/1/15.
//  Copyright (c) 2015 Raghu Vamsi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txtAmount;
@property (weak, nonatomic) IBOutlet UIImageView *imgButton;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segTransType;


@end

