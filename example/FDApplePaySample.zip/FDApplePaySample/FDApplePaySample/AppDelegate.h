//
//  AppDelegate.h
//  FDApplePaySample
//
//  Created by Raghu Vamsi on 6/1/15.
//  Copyright (c) 2015 Raghu Vamsi. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <InAppSDK/InAppSDK.h>


#define kApiKey             @"TAMzhyWggCSEaAILYEILmNC0Xciq0Spv" //replace this with your Payeezy API Key
#define kApiSecret          @"0320c734963c68703f44cd54b3531be38dfede5d75eb79ea42a004a19a0b5cfe" //replace this with your Payeezy API Secret
#define kMerchantToken      @"fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6" //replace this with your Payeezy Token
#define kApplePayMerchantId @"merchant.com.cert.PAFDF0" //replace with the merchantID assigned to this app on the Apple Developer Site

// Point to the PROD Environment
#define kEnvironment @"CERT"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) FDInAppPaymentProcessor *pePaymentProcessor;


@end

